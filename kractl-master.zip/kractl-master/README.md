Check the wiki page for more details.
https://github.com/kurpingspace2/kractl/wiki

## Dependencies
* discord.py

It should work out of the box. Built on python 3.8, works and tested on 3.7.

It's recommended to create a back-up of your .json files, since anything can happen.
